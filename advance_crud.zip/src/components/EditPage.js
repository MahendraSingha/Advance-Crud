import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'

function EditPage() {
    const [info, setInfo] = useState(JSON.parse(localStorage.getItem('dataKey')).map(u => {
        u.access = []
        return u
    }) || [])
    // const [data, setData] = useState([])
    console.log(info, '098')
    const navigate = useNavigate()


    const handleChange = (e, i) => {
        const arr = [...info]

        if (e.target.type === 'checkbox') {
            if (e.target.checked) {
                arr[i].isChecked = 'yes'

            } else {
                arr[i].isChecked = 'no'
            }
        } else {
            arr[i][e.target.name] = e.target.value
        }
        setInfo([...arr])
    }

    const accessChange = (e, i) => {
        if (e.target.checked) {
            info[i].access.push(e.target.value)

        } else {
            let arr = info[i].access.filter((elem, index) => elem !== e.target.value)
            info[i].access = [...arr]
        }
        setInfo([...info])
    }

    const handleUpdate = (e) => {
        console.log(info, 'info')
        let oldArr = JSON.parse(localStorage.getItem('dataKey'))
        info.map((elem, index) => {
            if (elem.isChecked === 'yes' || elem.isChecked === undefined) {
                let keys = Object.keys(oldArr[index])
                keys.map((elem) => {
                    oldArr[index][elem] = info[index][elem]
                })
                // oldArr[index].title = info[index].title
                // oldArr[index].note = info[index].note
                // oldArr[index] = info[index]

            }
            oldArr[index].access = info[index].access
        })

        console.log(oldArr, 'oldArr')
        // localStorage.setItem('dataKey', JSON.stringify(oldArr))
        // navigate('/')
        // console.log(info, 'info')

    }

    return (
        <div>
            <table className="table">
                <thead>
                    <tr>
                        <th scope="col">SERIAL NO</th>
                        <th scope="col">TITLE</th>
                        <th scope="col">NOTE</th>
                        <th scope="col">CHECKS</th>
                        <th scope="col">ACCESS</th>
                    </tr>
                </thead>
                <tbody>
                    {info &&
                        info.map((elem, i) => {
                            return (
                                <tr key={i}>
                                    <td>{i + 1}</td>
                                    <td>
                                        <input type='text' name='title' value={elem.title} onChange={(e) => handleChange(e, i)} />
                                    </td>
                                    <td>
                                        <input type='text' name='note' value={elem.note} onChange={(e) => handleChange(e, i)} />
                                    </td>
                                    <td>
                                        <input className="form-check-input" type="checkbox" id="flexCheckIndeterminate" defaultChecked onChange={(e) => handleChange(e, i)} />
                                    </td>
                                    <td>
                                        <input className="form-check-input" type="checkbox" value='store' id="flexCheckIndeterminate" onChange={(e) => accessChange(e, i)} />
                                        <label style={{ marginLeft: '10px' }}>Store</label><span style={{ marginLeft: '10px' }}></span>
                                        <input className="form-check-input" type="checkbox" value='warehouse' id="flexCheckIndeterminate" onChange={(e) => accessChange(e, i)} />
                                        <label style={{ marginLeft: '10px' }}>Warehouse</label><span style={{ marginLeft: '10px' }}></span>
                                        <input className="form-check-input" type="checkbox" value='inventory' id="flexCheckIndeterminate" onChange={(e) => accessChange(e, i)} />
                                        <label style={{ marginLeft: '10px' }}>Inventory</label>
                                    </td>
                                </tr>
                            )
                        })
                    }
                </tbody>
            </table>
            <button onClick={(e) => handleUpdate(e)} className='btn btn-success'>Update</button>
        </div>
    )
}

export default EditPage